const TagOptions = ["gym", "surf", "football", "cinema", "bike", "movies", "music", "food", "running", "party", "books", "study", "programming", "beach", "mountain", "animals", "travelling", "photography", "art", "culture", "dancing", "sailing"]

export default TagOptions