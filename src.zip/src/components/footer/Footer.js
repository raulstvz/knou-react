import "./Footer.css"

const Footer = () => {
    return(
        <div className="Footer__container">
           <span className="Footer__text"> © 2020 Knou. All rights reserved</span> 
        </div>
    )
};

export default Footer;