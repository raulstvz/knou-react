import "./ChatPage.css"

const ChatPage = () => {
<div>
    ChatPage
</div>
}

export default ChatPage;