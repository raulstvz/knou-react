import "./UserProfilePage.css"

const UserProfilePage = () => {
    return (
        <div>
            {console.log("found")};
        </div>

    )
}


export default UserProfilePage