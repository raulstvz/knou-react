import "./SwipePage.css"
import BoxMenu from "../components/boxmenu/BoxMenu"

const SwipePage = () => {

    
    return (
        <div>
        <BoxMenu />
         
        </div>
    )
}

export default SwipePage;